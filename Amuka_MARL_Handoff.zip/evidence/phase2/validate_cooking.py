import json
from pathlib import Path

from pymarlzooplus.envs.overcooked_wrapper import _OvercookedWrapper
from pymarlzooplus.envs.overcooked_ai.src.overcooked_ai_py.mdp.actions import Action

folder = Path(__file__).resolve().parent
env = _OvercookedWrapper(
    key="cramped_room",
    time_limit=100,
    seed=42,
    reward_type="sparse",
    render=False,
)

directions = {
    "up": (0, -1),
    "down": (0, 1),
    "right": (1, 0),
    "left": (-1, 0),
    "stay": (0, 0),
    "interact": "interact",
}
indices = {
    name: Action.INDEX_TO_ACTION.index(action)
    for name, action in directions.items()
}

steps = 0
total_reward = 0

try:
    env.reset()
    base = env.original_env.unwrapped.base_env
    print("Initial state:", base.state)
    print("Old dynamics:", base.mdp.old_dynamics)

    with (folder / "scripted_cooking_trajectory.jsonl").open("w") as log:
        def act(name, stage):
            global steps, total_reward
            before = str(base.state)
            reward, done, _ = env.step(
                [indices[name], indices["stay"]]
            )
            steps += 1
            total_reward += reward

            log.write(json.dumps({
                "step": steps,
                "stage": stage,
                "actions": [name, "stay"],
                "state_before": before,
                "state_after": str(base.state),
                "sparse_reward": reward,
                "done": bool(done),
            }) + "\n")
            log.flush()

            assert not done, f"Episode limit reached during {stage}"
            return reward

        # Agent 0 starts at (1, 2). Agent 1 remains at (3, 1).
        act("up", "approach onion dispenser")

        for onion in range(1, 4):
            act("left", "face onion dispenser")
            act("interact", f"collect onion {onion}")
            assert base.state.players[0].held_object.name == "onion"

            act("right", "approach pot")
            act("up", "face pot")
            act("interact", f"add onion {onion}")
            assert base.state.players[0].held_object is None

            if onion < 3:
                act("left", "return to onion dispenser")

        # Harmless under old dynamics; starts cooking under new dynamics.
        act("interact", "start cooking")
        print("Pot after loading:", base.state.get_object((2, 0)))

        # Collect a dish at (1, 3), then return to the pot.
        for name in ("down", "left", "down", "interact"):
            act(name, "collect dish")
        assert base.state.players[0].held_object.name == "dish"

        for name in ("right", "up", "up"):
            act(name, "return to pot")

        while not base.mdp.soup_ready_at_location(base.state, (2, 0)):
            assert steps < 90, "Soup did not become ready in time"
            act("stay", "wait for cooking")

        act("interact", "collect ready soup")
        assert base.state.players[0].held_object.name == "soup"

        # Reach (3, 2), face the serving counter at (3, 3).
        for name in ("down", "right", "down"):
            act(name, "approach serving counter")

        delivery_reward = act("interact", "deliver soup")
        assert delivery_reward == 20, (
            f"Unexpected delivery reward: {delivery_reward}"
        )
        assert base.state.players[0].held_object is None
        assert total_reward == 20

    summary = {
        "status": "PASS",
        "layout": "cramped_room",
        "reward_type": "sparse",
        "steps": steps,
        "delivery_reward": delivery_reward,
        "total_reward": total_reward,
        "agent_1_behavior": "stay throughout",
        "initial_state_modified": False,
    }
    (folder / "scripted_cooking_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )

    print("Steps:", steps)
    print("Delivery reward:", delivery_reward)
    print("Total sparse reward:", total_reward)
    print("PASS: Soup cooked and delivered from the normal initial state")

finally:
    env.close()
