from pymarlzooplus.envs.overcooked_wrapper import _OvercookedWrapper
from pymarlzooplus.envs.overcooked_ai.src.overcooked_ai_py.mdp.overcooked_mdp import SoupState
from pymarlzooplus.envs.overcooked_ai.src.overcooked_ai_py.mdp.actions import Action

env = _OvercookedWrapper(
    key="cramped_room",
    time_limit=100,
    seed=42,
    reward_type="sparse",
    render=False,
)

stay = Action.INDEX_TO_ACTION.index((0, 0))
interact = Action.INDEX_TO_ACTION.index("interact")

try:
    env.reset()
    base = env.original_env.unwrapped.base_env

    # Place physical agent 0 beside the serving counter, facing it.
    player = base.state.players[0]
    player.position = (3, 2)
    player.orientation = (0, 1)
    player.held_object = SoupState.get_soup(
        position=player.position,
        num_onions=3,
        finished=True,
    )

    print("TEST 1: Controlled sparse-reward delivery")
    print("Initial state:", base.state)

    idle_reward, idle_done, _ = env.step([stay, stay])
    assert idle_reward == 0, f"Unexpected idle reward: {idle_reward}"
    assert not idle_done, "Episode ended before delivery"

    delivery_reward, delivery_done, _ = env.step([interact, stay])
    assert delivery_reward > 0, f"No delivery reward: {delivery_reward}"
    assert base.state.players[0].held_object is None, "Soup was not served"

    print("Idle reward:", idle_reward)
    print("Delivery reward:", delivery_reward)
    print("Final state:", base.state)
    print("PASS: Serving soup produces a positive sparse reward")

    print("\nTEST 2: Episode horizon")
    env.reset()
    total_reward = 0

    for step in range(1, 101):
        reward, done, _ = env.step([stay, stay])
        total_reward += reward
        assert bool(done) == (step == 100), (
            f"Unexpected termination at step {step}: {done}"
        )

    assert total_reward == 0, f"Unexpected reward: {total_reward}"
    print("Episode ended at step:", step)
    print("Total idle reward:", total_reward)
    print("PASS: Unfinished episode ends at the 100-step limit")

finally:
    env.close()
