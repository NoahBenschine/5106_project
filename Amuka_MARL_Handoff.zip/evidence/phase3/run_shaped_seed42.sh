#!/bin/bash
set -o pipefail

/usr/bin/time -l python -m pymarlzooplus.main \
  --config=mappo \
  --env-config=overcooked \
  with \
  env_args.key=cramped_room \
  env_args.reward_type=shaped \
  env_args.time_limit=100 \
  env_args.render=False \
  use_cuda=False \
  batch_size_run=1 \
  batch_size=8 \
  buffer_size=8 \
  t_max=50000 \
  test_nepisode=10 \
  test_interval=10000 \
  log_interval=10000 \
  runner_log_interval=10000 \
  learner_log_interval=10000 \
  save_model=True \
  save_model_interval=10000 \
  local_results_path=evidence/phase3/framework_results \
  use_tensorboard=False \
  seed=42 \
  2>&1 | tee evidence/phase3/mappo_shaped_seed42_console.txt
