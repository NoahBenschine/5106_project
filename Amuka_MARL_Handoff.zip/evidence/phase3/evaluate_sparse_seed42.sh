#!/bin/bash
set -o pipefail

/usr/bin/time -l python -m pymarlzooplus.main \
  --config=mappo \
  --env-config=overcooked \
  with \
  env_args.key=cramped_room \
  env_args.reward_type=sparse \
  env_args.time_limit=100 \
  env_args.render=False \
  use_cuda=False \
  batch_size_run=1 \
  batch_size=8 \
  buffer_size=8 \
  checkpoint_path=evidence/phase3/mappo_shaped_seed42_50k/models \
  load_step=50100 \
  evaluate=True \
  test_nepisode=20 \
  save_model=False \
  use_tensorboard=False \
  seed=42 \
  2>&1 | tee evidence/phase3/sparse_evaluation_console.txt
