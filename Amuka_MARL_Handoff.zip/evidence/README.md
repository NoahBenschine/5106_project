# Amuka's experiment handoff

Experiments completed October 11–12, 2026.

## Results

- Phase 1: CPU MAPPO feasibility run completed 5,100 sparse-reward
  steps. Logged training and evaluation returns were zero.
- Phase 2: Controlled delivery earned 20; an idle episode ended
  at 100 steps. Scripted cooking from the normal initial state
  succeeded in 43 steps for reward 20 while agent 1 stayed idle.
- Phase 3: Shaped-reward MAPPO completed 50,100 steps.
  Final logged training/evaluation shaped returns: 8.93 / 8.10.
  Greedy sparse-reward evaluation requested 20 episodes and
  returned zero. Learned soup delivery remains undemonstrated.

These are single-seed diagnostic experiments, not a controlled
comparison of reward types. LLM integration is not implemented.

## Evidence

- phase1/: feasibility configuration, metrics, plots, dependency
  snapshot, framework commit, and hardware/software records.
- phase2/: validation scripts, outputs, and successful trajectory.
- phase3/: training/evaluation commands, logs, archived runs,
  and six model checkpoints.

Latest checkpoint:
phase3/mappo_shaped_seed42_50k/models/50100/

## Reproduction

The team repository contains evidence; it does not contain the
PyMARLzoo+ framework. Scripts must run from the framework root.

For a fresh framework checkout, starting in the team repository:

```bash
git clone https://github.com/AILabDsUnipi/pymarlzooplus.git ../pymarlzooplus-reproduce
git -C ../pymarlzooplus-reproduce checkout "$(cat evidence/phase1/framework-commit.txt)"
cp -R evidence ../pymarlzooplus-reproduce/
cd ../pymarlzooplus-reproduce
```

Use a compatible Python environment before running:

```bash
PYTHONPATH="$PWD" python evidence/phase2/validate_delivery.py
PYTHONPATH="$PWD" python evidence/phase2/validate_cooking.py
```

Evaluate the existing checkpoint without training:

```bash
bash evidence/phase3/evaluate_sparse_seed42.sh
```

Start a NEW shaped training run:

```bash
bash evidence/phase3/run_shaped_seed42.sh
```

The shell scripts use macOS `/usr/bin/time -l`; Linux users must
adapt the timing invocation. The dependency snapshot records the
working macOS environment, not a universal installation recipe.

Compatibility adjustments used: setuptools==80.9.0,
opencv-python<4.12, numpy<2, and plain pettingzoo instead of
pettingzoo[all].

Rerunning scripts can overwrite copied console and validation
outputs. Preserve the committed evidence when making new experiments.
Historical configuration files contain the original machine's paths.

## Next work

Inspect learned-policy trajectories to identify where cooking stops.
Preserve per-agent events for trajectory logging and LLM supervision.
The current wrapper replaces sparse rewards in shaped mode and
discards event information from its returned info dictionary.
